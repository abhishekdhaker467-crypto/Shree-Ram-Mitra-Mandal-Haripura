श्री राम मित्र मंडल हरिपुरा — सेटअप गाइड

इस ZIP में index.html (वेबसाइट कोड), firestore.rules (डेटाबेस सुरक्षा नियम), firebase.json हैं।
यह अभी लाइव वेबसाइट नहीं है। Firebase config भरकर Hosting पर deploy करना आवश्यक है।

1) https://console.firebase.google.com/ पर नया प्रोजेक्ट बनाएं।
2) Project Overview में Web app (</>) जोड़ें। Project settings > Your apps से config कॉपी करें।
3) index.html में cfg के apiKey, authDomain, projectId, storageBucket, messagingSenderId, appId बदलें।
4) Build > Authentication > Sign-in method में Email/Password और Anonymous दोनों चालू करें।
5) Authentication > Users में अपना एडमिन ईमेल/पासवर्ड बनाएं और UID कॉपी करें।
6) Build > Firestore Database > Create database करें।
7) Firestore > Rules में firestore.rules का पूरा कोड paste करके Publish करें।
8) Firestore > Data में admins collection बनाएं। Document ID एडमिन का UID रखें और field admin (Boolean) = true जोड़ें।
9) मोबाइल ब्राउज़र से https://shell.cloud.google.com/ खोलें, उसी Google अकाउंट से लॉगिन करें। ZIP को Cloud Shell में अपलोड और extract करें।
10) प्रोजेक्ट फ़ोल्डर में public नाम का फ़ोल्डर बनाएं और index.html उसमें रखें। firebase.json और firestore.rules प्रोजेक्ट फ़ोल्डर के root में रखें।
11) Firebase Hosting गाइड: https://firebase.google.com/docs/hosting/quickstart
Cloud Shell terminal में चलाएं:
npm install -g firebase-tools
firebase login
firebase use --add
firebase deploy
यदि Hosting initialize नहीं किया है तो पहले firebase init hosting चलाएं और public directory में public चुनें।
12) deploy पूरा होने पर https://PROJECT_ID.web.app जैसा लिंक मिलेगा; यही वेबसाइट का लिंक है।

सुरक्षा:
- एडमिन UID किसी को न दें। पासवर्ड साझा न करें।
- सदस्यों के पते/मोबाइल निजी हैं; सूची केवल एडमिन लॉगिन के बाद दिखती है।
- Firebase config HTML में दिख सकती है; सुरक्षा Firestore Rules और Authentication से होती है। Private/service-account key कभी HTML में न डालें।
- सार्वजनिक फॉर्म पर स्पैम का जोखिम रहता है; वास्तविक उपयोग से पहले Firebase App Check और abuse protection जोड़ना उचित है।
- WhatsApp अपने-आप संदेश नहीं भेजता; WhatsApp खुलने पर Send दबाना होगा।
- वेबसाइट भुगतान को सत्यापित नहीं करती। रसीद जारी करना अलग प्रक्रिया है।
- सदस्यता/डेटाबेस sync के लिए इंटरनेट आवश्यक है।
